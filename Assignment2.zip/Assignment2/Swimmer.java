
public class Swimmer extends Animal{

	public Swimmer(String type, String name, String gender, String environment) {
		super(type, name, gender, environment);
		// TODO Auto-generated constructor stub
	}
	public void Swim() {
		System.out.println("I can swim");
	}
}
