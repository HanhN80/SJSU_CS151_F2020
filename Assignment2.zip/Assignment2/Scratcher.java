
public class Scratcher extends Domesticated{

	public Scratcher(String type, String name, String gender, String environment) {
		super(type, name, gender, environment);
		// TODO Auto-generated constructor stub
}
	public void Scratch() {
		System.out.println("I can scratch");
	}
}
